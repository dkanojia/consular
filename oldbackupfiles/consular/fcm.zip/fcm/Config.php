<?php 
 define('DB_USERNAME','gotcha_user');
 define('DB_PASSWORD','gotcha_user12');
 define('DB_NAME','gotcha_pspy');
 define('DB_HOST','localhost');
 
 //defined a new constant for firebase api key
 define('FIREBASE_API_KEY', 'AIzaSyALoH4_0yoRxF4TLKHQO6N_N0YiVwmk06k');
 