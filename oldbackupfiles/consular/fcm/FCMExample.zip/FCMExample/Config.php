<?php 
 define('DB_USERNAME','root');
 define('DB_PASSWORD','');
 define('DB_NAME','akash');
 define('DB_HOST','localhost');
 
 //defined a new constant for firebase api key
 define('FIREBASE_API_KEY', 'AAAAcWGWvb0:APA91bHR6hEQmLGjDdIg7gFtXPw2i3vHqKPwfVFtWhFN4cPC-EwG3s0BuMWNMM0GkGL7mi7rqAmf-yUsqHlsRNQupFu6TNndKBWtFvCPJ6xzyyliSahO7QbNVEeEE5ndH9ee7JtjrVML');
 